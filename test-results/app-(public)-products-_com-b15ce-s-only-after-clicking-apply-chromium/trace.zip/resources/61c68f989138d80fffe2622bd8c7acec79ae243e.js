(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_6f0bb020._.js",
  "static/chunks/85c95_react-hook-form_dist_index_esm_mjs_76afa9ea._.js",
  "static/chunks/a8d7e_zod_v4_f9812d86._.js",
  "static/chunks/2c99e_@radix-ui_react-select_dist_index_mjs_785da972._.js",
  "static/chunks/7d626_next_a6deb3ce._.js",
  "static/chunks/node_modules__pnpm_7fed40a6._.js"
],
    source: "dynamic"
});
