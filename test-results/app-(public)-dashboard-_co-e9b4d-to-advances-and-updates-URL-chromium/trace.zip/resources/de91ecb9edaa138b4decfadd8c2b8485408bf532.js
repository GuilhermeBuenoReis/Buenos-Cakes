(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7d626_next_3c7f8041._.js",
  "static/chunks/190e3_framer-motion_dist_es_d6859c23._.js",
  "static/chunks/9c4a8_motion-dom_dist_es_92aec209._.js",
  "static/chunks/node_modules__pnpm_43746b8d._.js",
  "static/chunks/src_app_(public)_dashboard__components_7b1e8456._.js"
],
    source: "dynamic"
});
